import numpy as np
from scipy.io import savemat

from ecgaf.io import load_dataset, load_record


def test_loads_physionet_style_files(tmp_path):
    for name, label in [("A00001", "N"), ("A00002", "A"), ("A00003", "~")]:
        savemat(tmp_path / f"{name}.mat", {"val": (np.arange(3000)[None, :] % 50).astype(np.int16)})
        (tmp_path / f"{name}.hea").write_text(f"{name} 1 300 3000\n{name}.mat 16 1000/mV 16 0 0 0 0 ECG\n")
    (tmp_path / "REFERENCE.csv").write_text("A00001,N\nA00002,A\nA00003,~\n")

    sig, fs = load_record(tmp_path / "A00001")
    assert fs == 300 and len(sig) == 3000 and sig.max() <= 0.05  # 49 / 1000 mV

    signals, labels = load_dataset(tmp_path)
    assert labels == ["N", "A"]  # noisy '~' record excluded by default
    assert len(load_dataset(tmp_path, include_noisy=True)[1]) == 3
