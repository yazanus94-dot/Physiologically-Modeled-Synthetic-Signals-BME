import numpy as np
import pytest

from ecgaf import FS
from ecgaf.features import FEATURE_NAMES, extract_features
from ecgaf.model import challenge_score, cross_validate
from ecgaf.peaks import detect_r_peaks
from ecgaf.preprocess import bandpass, normalise
from ecgaf.synthetic import generate_dataset, generate_record


def _clean_train(rr=0.8, beats=30):
    """Noise-free ECG with perfectly known R-peak positions."""
    from ecgaf.synthetic import _P, _QRS_T, _add_beat
    sig = np.zeros(int((beats * rr + 1) * FS))
    truth = [int((0.5 + k * rr) * FS) for k in range(beats)]
    for r in truth:
        _add_beat(sig, r, [_P] + _QRS_T, 1.0, FS)
    return sig, np.array(truth)


def test_bandpass_removes_baseline_wander():
    t = np.arange(0, 20, 1 / FS)
    wander = 2.0 * np.sin(2 * np.pi * 0.1 * t)
    assert np.std(bandpass(wander)[FS * 2:-FS * 2]) < 0.05 * np.std(wander)


def test_normalise_is_gain_invariant():
    rng = np.random.default_rng(0)
    x = rng.normal(size=3000)
    assert np.allclose(normalise(x), normalise(5 * x), atol=1e-9)


def test_r_peak_detector_finds_every_beat_on_clean_signal():
    sig, truth = _clean_train()
    found = detect_r_peaks(normalise(bandpass(sig)))
    tol = int(0.05 * FS)
    matched = sum(np.any(np.abs(found - t) <= tol) for t in truth)
    assert matched >= len(truth) - 1, f"matched {matched}/{len(truth)}"
    assert len(found) <= len(truth) + 1, "too many false positives"


@pytest.mark.parametrize("label", ["N", "A", "O"])
def test_features_are_finite_and_complete(label):
    sig = generate_record(label, np.random.default_rng(1))
    feats = extract_features(sig)
    assert list(feats) == FEATURE_NAMES
    assert all(np.isfinite(v) for v in feats.values())


def test_af_is_more_irregular_than_normal():
    rng = np.random.default_rng(7)
    cv = {lab: np.mean([extract_features(generate_record(lab, rng))["rr_cv"] for _ in range(15)]) for lab in "NA"}
    assert cv["A"] > 2 * cv["N"]


def test_flat_signal_does_not_crash():
    feats = extract_features(np.zeros(30 * FS))
    assert all(np.isfinite(v) for v in feats.values())


def test_challenge_score_matches_hand_calculation():
    y_true = ["N", "N", "A", "A", "O", "O"]
    y_pred = ["N", "A", "A", "A", "O", "N"]
    m = challenge_score(y_true, y_pred)
    # N: P=1/2 R=1/2 F1=.5 ; A: P=2/3 R=1 F1=.8 ; O: P=1 R=1/2 F1=2/3
    assert abs(m["challenge_score"] - (0.5 + 0.8 + 2 / 3) / 3) < 1e-9


def test_end_to_end_beats_chance_on_synthetic_data():
    from ecgaf.features import build_feature_matrix
    signals, labels = generate_dataset(n_per_class=30, seed=3)
    _, metrics = cross_validate(build_feature_matrix(signals), labels, folds=3)
    assert metrics["challenge_score"] > 0.6  # chance is ~0.33
