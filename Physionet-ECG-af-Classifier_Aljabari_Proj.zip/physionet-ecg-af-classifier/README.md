# 🫀 ECG Rhythm Classification — PhysioNet/CinC 2017 Style Pipeline

![Python](https://img.shields.io/badge/Python-3.10+-blue) ![scikit--learn](https://img.shields.io/badge/scikit--learn-RandomForest-orange) ![Tests](https://img.shields.io/badge/tests-11_passing-brightgreen)

A reproducible, end-to-end pipeline that classifies **single-lead ECG recordings into Normal / Atrial Fibrillation (AF) / Other rhythm**,
following the task and scoring rule of the **[PhysioNet/Computing in Cardiology Challenge 2017](https://physionet.org/content/challenge-2017/1.0.0/)**.

> **Honest scope statement.** This is a **self-directed portfolio project**. It is *not* an official Challenge entry, has no official
> placement, and the numbers below come from **synthetic** data. Results on the real Challenge data must be produced by running `ecgaf train` (instructions below).

Author: **Yazan Aljabari** · Biomedical Engineer · [GitHub](https://github.com/yazanus94-dot) · [LinkedIn](https://linkedin.com/in/yazan-aljabari-878202139)

## Pipeline
```
raw ECG (300 Hz) → band-pass 0.5–40 Hz → robust normalisation → R-peak detection (Pan-Tompkins style)
   → 30 features (HRV, Poincaré, spectral f-wave power, quality) → Random Forest → F1 per class → challenge score
```
| Module | Purpose |
|---|---|
| `ecgaf/preprocess.py` | zero-phase Butterworth band-pass, median/IQR normalisation |
| `ecgaf/peaks.py` | QRS detector: band-pass → derivative → square → integrate → adaptive threshold → refinement |
| `ecgaf/features.py` | 30 features: RR statistics (SDNN, RMSSD, pNN50…), Poincaré SD1/SD2, RR entropy, turning-point ratio, ectopy fraction, 4–9 Hz f-wave band power, spectral entropy, kurtosis/skew |
| `ecgaf/model.py` | class-balanced random forest, stratified 5-fold **out-of-fold** evaluation, official scoring: mean(F1_N, F1_A, F1_O) |
| `ecgaf/io.py` | loader for the real PhysioNet 2017 files (`.mat` + `.hea` + `REFERENCE.csv`) |
| `ecgaf/synthetic.py` | physiologically-motivated ECG simulator so the project runs offline and is unit-testable |

## Quick start
```bash
pip install -r requirements.txt && pip install -e .
pytest -q                                   # 11 tests
python -m ecgaf.cli demo                    # synthetic end-to-end run, offline -> reports/demo/
```
### Run on the real Challenge data (this is the result recruiters care about)
```bash
python scripts/download_physionet2017.py    # ~100 MB, open data
python -m ecgaf.cli train --data data/training2017
# -> reports/physionet2017/metrics.json, confusion_matrix.png, feature_importance.png
```
After you run it, **paste your real scores into the table below** — that's the number that matters.

## Results
| Dataset | F1 Normal | F1 AF | F1 Other | Challenge score |
|---|---|---|---|---|
| Synthetic (450 records, 5-fold CV) | 0.93 | 0.95 | 0.88 | **0.92** |
| **PhysioNet/CinC 2017 training set (5-fold CV)** | _run `ecgaf train`_ | _…_ | _…_ | _…_ |

The synthetic score only shows the code works end-to-end; synthetic data is far easier than real recordings, and top 2017 teams scored roughly 0.8 on the hidden test set.

![Example ECG with detected R peaks](docs/images/example_ecg.png)
![Confusion matrix](docs/images/confusion_matrix.png)

## Engineering notes
* **No leakage:** every score is out-of-fold; features are computed per record, so no information crosses folds.
* **Robustness:** flat/dead leads, too-few-beats records and NaN statistics are handled and unit-tested (a test caught a real NaN bug during development).
* **Tested components:** filter behaviour, gain invariance, peak-detector recall/precision on a signal with known R positions, feature completeness, scoring maths checked by hand, loader on PhysioNet-formatted files, end-to-end above chance.
* **CI:** GitHub Actions runs tests and the synthetic demo on every push.

## Known limitations (read before trusting any number)
1. **Wide ectopic beats can be missed** by the 5–15 Hz QRS detector (visible in the "Other" strip above) — a wavelet or adaptive-band detector would improve this.
2. **No P-wave or waveform-level features and no deep learning.** Competitive entries used CNN/RNN models on raw signal or spectrograms; this is a strong, interpretable classical baseline.
3. The noisy class (`~`) is excluded, as in the original 3-class scoring.
4. Single random forest, no hyper-parameter search; trained and evaluated on the public training set only — **no hidden-test-set score.**

## Ideas to extend (good next steps)
1D-CNN on raw ECG · wavelet QRS detector · SQI-based noisy-record rejection · calibration & per-class thresholds · SHAP explanations.

## Data & citation
Clifford GD, Liu C, Moody B, et al. *AF Classification from a Short Single Lead ECG Recording: The PhysioNet/Computing in Cardiology Challenge 2017.* Computing in Cardiology 2017; 44.
Goldberger A, et al. *PhysioBank, PhysioToolkit, and PhysioNet.* Circulation 101(23), 2000.
The dataset is **not** redistributed here; the download script fetches it from PhysioNet.
