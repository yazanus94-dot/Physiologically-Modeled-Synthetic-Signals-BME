# Project Report — Single-lead ECG rhythm classification

## Problem
Classify a 9–60 s single-lead ECG (300 Hz) as Normal, AF, Other (or too noisy). AF is irregularly irregular in time (RR intervals) and shows no P waves / fibrillatory baseline activity; "Other" contains ectopy, blocks and other abnormal rhythms, which is the hardest class.

## Design decisions
| Decision | Rationale |
|---|---|
| Hand-crafted HRV + spectral features | Interpretable, fast, strong baseline; mirrors clinical reasoning (RR irregularity, f-waves) |
| Random forest with class weights | Robust on small tabular data, handles class imbalance (Normal ≫ AF) without tuning |
| Official scoring (mean F1 of 3 classes) | Accuracy hides poor minority-class performance |
| Out-of-fold CV | Honest estimate without a separate test set |
| Synthetic simulator | Enables offline tests / CI; explicitly *not* used to claim performance |

## Validation strategy
Unit tests for each stage; known-answer tests (peak detector on a signal with exact R positions, F1 computed by hand); robustness tests (flat lead); integration test (above-chance on synthetic data).

## Error analysis (synthetic run)
Most confusion is between **Other ↔ Normal/AF**: ectopic records with few premature beats look normal, and "irregular sinus" records overlap AF on RR statistics — by design, as in real data. Missed wide ectopic beats lower RR-based ectopy features.

## Next steps
Report real-data metrics; add a wavelet detector; compare to a 1D-CNN; analyse errors by signal quality.
