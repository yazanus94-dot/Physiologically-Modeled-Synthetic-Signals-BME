"""R-peak detection (simplified Pan-Tompkins).

band-pass 5-15 Hz -> derivative -> squaring -> moving-window integration -> adaptive-height peak picking
-> refinement of each peak to the local maximum of the band-passed ECG.
"""
import numpy as np
from scipy.signal import butter, find_peaks, sosfiltfilt

from ecgaf import FS


def detect_r_peaks(sig: np.ndarray, fs: int = FS) -> np.ndarray:
    """Return sample indices of detected R peaks (sorted)."""
    sos = butter(2, [5, 15], btype="bandpass", fs=fs, output="sos")
    qrs = sosfiltfilt(sos, sig)
    squared = np.gradient(qrs) ** 2
    win = max(1, int(0.12 * fs))
    integrated = np.convolve(squared, np.ones(win) / win, mode="same")

    # Threshold relative to a robust high percentile -> resistant to single large artefacts.
    ref = np.percentile(integrated, 99)
    peaks, _ = find_peaks(integrated, height=0.25 * ref, distance=int(0.25 * fs))

    # Refine to the true R-peak position (max |amplitude| in +/-60 ms of the band-passed signal).
    half = int(0.06 * fs)
    refined = []
    for p in peaks:
        lo, hi = max(0, p - half), min(len(sig), p + half)
        refined.append(lo + int(np.argmax(np.abs(qrs[lo:hi]))))
    return np.unique(np.array(refined, dtype=int))
