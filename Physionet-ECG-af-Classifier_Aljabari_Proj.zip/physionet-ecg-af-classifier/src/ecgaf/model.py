"""Training / evaluation with the PhysioNet 2017 scoring rule (mean F1 of Normal, AF and Other)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.ensemble import RandomForestClassifier  # noqa: E402
from sklearn.metrics import confusion_matrix, f1_score  # noqa: E402
from sklearn.model_selection import StratifiedKFold, cross_val_predict  # noqa: E402

from ecgaf import CLASSES  # noqa: E402


def make_model(seed: int = 42) -> RandomForestClassifier:
    return RandomForestClassifier(n_estimators=400, min_samples_leaf=2, class_weight="balanced",
                                  n_jobs=-1, random_state=seed)


def challenge_score(y_true, y_pred) -> dict:
    """F1 per class and the official 2017 final score = mean(F1_N, F1_A, F1_O)."""
    f1s = f1_score(y_true, y_pred, labels=CLASSES, average=None, zero_division=0)
    out = {f"F1_{c}": float(v) for c, v in zip(CLASSES, f1s)}
    out["challenge_score"] = float(np.mean(f1s))
    return out


def cross_validate(X: pd.DataFrame, y, folds: int = 5, seed: int = 42):
    """Stratified k-fold out-of-fold predictions -> (y_pred, metrics). No record is ever scored by a model that saw it."""
    cv = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    y_pred = cross_val_predict(make_model(seed), X, y, cv=cv)
    return y_pred, challenge_score(y, y_pred)


def plot_confusion(y_true, y_pred, path: Path, title: str) -> None:
    cm = confusion_matrix(y_true, y_pred, labels=CLASSES, normalize="true")
    fig, ax = plt.subplots(figsize=(4.6, 4))
    im = ax.imshow(cm, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(3), CLASSES); ax.set_yticks(range(3), CLASSES)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(title, fontsize=9)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{cm[i, j]:.2f}", ha="center", va="center", color="white" if cm[i, j] > 0.5 else "black")
    fig.colorbar(im, fraction=0.046); fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_importance(model, columns, path: Path, top: int = 15) -> None:
    imp = pd.Series(model.feature_importances_, index=columns).sort_values().tail(top)
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    imp.plot.barh(ax=ax, color="#2563a8"); ax.set_title("Top feature importances (random forest)", fontsize=9)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)
