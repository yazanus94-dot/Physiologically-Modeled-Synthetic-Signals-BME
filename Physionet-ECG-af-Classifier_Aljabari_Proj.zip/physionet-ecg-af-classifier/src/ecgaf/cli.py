"""Command line interface.

  python -m ecgaf.cli demo  [--n-per-class 150]            # synthetic data, runs offline
  python -m ecgaf.cli train --data data/training2017       # real PhysioNet/CinC 2017 data
"""
import argparse
import json
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

from ecgaf import FS  # noqa: E402
from ecgaf.features import build_feature_matrix  # noqa: E402
from ecgaf.model import challenge_score, cross_validate, make_model, plot_confusion, plot_importance  # noqa: E402
from ecgaf.peaks import detect_r_peaks  # noqa: E402
from ecgaf.preprocess import bandpass, normalise  # noqa: E402
from ecgaf.synthetic import generate_dataset  # noqa: E402


def _example_strips(signals, labels, path: Path) -> None:
    fig, axes = plt.subplots(3, 1, figsize=(9, 6), sharex=True)
    for ax, lab, name in zip(axes, "NAO", ["Normal sinus", "Atrial fibrillation", "Other (ectopic beats)"]):
        sig = signals[labels.index(lab)]
        filt = normalise(bandpass(sig))
        pk = detect_r_peaks(filt)
        seg = slice(0, 8 * FS)
        t = np.arange(len(filt))[seg] / FS
        ax.plot(t, filt[seg], lw=0.8, color="#1b3a6b")
        pk = pk[pk < 8 * FS]
        ax.plot(pk / FS, filt[pk], "rv", ms=5, label="detected R peaks")
        ax.set_ylabel(name, fontsize=8); ax.legend(loc="upper right", fontsize=7)
    axes[-1].set_xlabel("time (s)")
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def _run(signals, labels, out: Path, title: str) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    X = build_feature_matrix(signals)
    y_pred, metrics = cross_validate(X, labels)
    model = make_model().fit(X, labels)
    plot_confusion(labels, y_pred, out / "confusion_matrix.png", title)
    plot_importance(model, X.columns, out / "feature_importance.png")
    metrics.update(n_records=len(labels), seconds=round(time.time() - t0, 1))
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))
    return metrics


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="ecgaf")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("demo", help="end-to-end run on synthetic ECG (offline)")
    d.add_argument("--n-per-class", type=int, default=150)
    d.add_argument("--out", default="reports/demo")
    t = sub.add_parser("train", help="5-fold CV on the PhysioNet/CinC 2017 training set")
    t.add_argument("--data", default="data/training2017")
    t.add_argument("--max-records", type=int, default=None)
    t.add_argument("--out", default="reports/physionet2017")
    a = ap.parse_args(argv)

    if a.cmd == "demo":
        signals, labels = generate_dataset(a.n_per_class)
        out = Path(a.out)
        out.mkdir(parents=True, exist_ok=True)
        _example_strips(signals, labels, out / "example_ecg.png")
        _run(signals, labels, out, "SYNTHETIC data - 5-fold CV")
    else:
        from ecgaf.io import load_dataset
        signals, labels = load_dataset(a.data, a.max_records)
        _run(signals, labels, Path(a.out), "PhysioNet/CinC 2017 - 5-fold CV")


if __name__ == "__main__":
    main()
