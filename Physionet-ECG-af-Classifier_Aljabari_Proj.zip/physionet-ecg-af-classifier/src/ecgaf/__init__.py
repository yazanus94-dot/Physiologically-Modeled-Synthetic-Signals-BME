"""ecgaf - single-lead ECG rhythm classification (Normal / AF / Other)."""
__version__ = "0.1.0"
FS = 300  # Hz, sampling rate of the PhysioNet/CinC 2017 recordings
CLASSES = ["N", "A", "O"]  # Normal sinus, Atrial fibrillation, Other rhythm
CLASS_NAMES = {"N": "Normal", "A": "AF", "O": "Other"}
