"""Feature extraction: heart-rate-variability (RR irregularity) + spectral + morphology/quality descriptors."""
import numpy as np
import pandas as pd
from scipy.signal import welch
from scipy.stats import kurtosis, skew

from ecgaf import FS
from ecgaf.peaks import detect_r_peaks
from ecgaf.preprocess import bandpass, normalise

FEATURE_NAMES = [
    "n_beats", "hr_bpm", "rr_mean", "rr_median", "rr_std", "rr_cv", "rr_min", "rr_max", "rr_range",
    "rmssd", "rmssd_norm", "sdsd", "pnn50", "pnn20", "ectopy_frac", "rr_entropy", "turning_point_ratio",
    "sd1", "sd2", "sd1_sd2", "rr_mad_norm", "long_pause_frac",
    "pow_low", "pow_fwave", "pow_high", "fwave_ratio", "spec_entropy",
    "sig_kurtosis", "sig_skew", "qrs_amp_cv",
]


def _entropy(values: np.ndarray, bins: int = 10) -> float:
    hist, _ = np.histogram(values, bins=bins)
    p = hist[hist > 0] / hist.sum()
    return float(-(p * np.log2(p)).sum())


def _rr_features(rr: np.ndarray) -> dict:
    d = np.diff(rr)
    med = np.median(rr)
    mean = rr.mean()
    tp = np.sum((rr[1:-1] - rr[:-2]) * (rr[1:-1] - rr[2:]) > 0) / max(1, len(rr) - 2)
    sd1 = np.std(d) / np.sqrt(2) if len(d) else 0.0
    sd2 = np.sqrt(max(0.0, 2 * np.std(rr) ** 2 - 0.5 * np.std(d) ** 2)) if len(d) else 0.0
    return {
        "hr_bpm": 60.0 / mean, "rr_mean": mean, "rr_median": med, "rr_std": rr.std(), "rr_cv": rr.std() / mean,
        "rr_min": rr.min(), "rr_max": rr.max(), "rr_range": rr.max() - rr.min(),
        "rmssd": np.sqrt(np.mean(d ** 2)) if len(d) else 0.0,
        "rmssd_norm": (np.sqrt(np.mean(d ** 2)) / mean) if len(d) else 0.0,
        "sdsd": np.std(d) if len(d) else 0.0,
        "pnn50": np.mean(np.abs(d) > 0.05) if len(d) else 0.0,
        "pnn20": np.mean(np.abs(d) > 0.02) if len(d) else 0.0,
        "ectopy_frac": np.mean(np.abs(rr - med) > 0.2 * med),
        "rr_entropy": _entropy(rr), "turning_point_ratio": tp,
        "sd1": sd1, "sd2": sd2, "sd1_sd2": sd1 / sd2 if sd2 > 1e-9 else 0.0,
        "rr_mad_norm": np.median(np.abs(rr - med)) / med,
        "long_pause_frac": np.mean(rr > 1.5 * med),
    }


def extract_features(raw: np.ndarray, fs: int = FS) -> dict:
    """Compute the full feature dictionary for one ECG record (all keys of FEATURE_NAMES)."""
    with np.errstate(all="ignore"):
        sig = normalise(bandpass(raw, fs=fs))
    peaks = detect_r_peaks(sig, fs=fs)
    feats = dict.fromkeys(FEATURE_NAMES, 0.0)
    feats["n_beats"] = float(len(peaks))

    if len(peaks) >= 4:
        rr = np.diff(peaks) / fs
        rr = rr[(rr > 0.25) & (rr < 3.0)]  # physiologically plausible only
        if len(rr) >= 3:
            feats.update(_rr_features(rr))
        amps = np.abs(sig[peaks])
        feats["qrs_amp_cv"] = float(amps.std() / (amps.mean() + 1e-9))

    f, pxx = welch(sig, fs=fs, nperseg=min(len(sig), 2048))
    total = pxx[(f >= 0.5) & (f <= 40)].sum() + 1e-12
    feats["pow_low"] = pxx[(f >= 0.5) & (f < 4)].sum() / total
    feats["pow_fwave"] = pxx[(f >= 4) & (f <= 9)].sum() / total
    feats["pow_high"] = pxx[(f > 9) & (f <= 40)].sum() / total
    feats["fwave_ratio"] = feats["pow_fwave"] / (feats["pow_low"] + 1e-9)
    p = pxx[(f >= 0.5) & (f <= 40)] / total
    feats["spec_entropy"] = float(-(p[p > 0] * np.log2(p[p > 0])).sum())
    feats["sig_kurtosis"], feats["sig_skew"] = float(kurtosis(sig)), float(skew(sig))
    # A dead/flat lead gives NaN statistics (e.g. kurtosis of a constant) -> map to 0 so one bad record never breaks a batch.
    return {k: float(np.nan_to_num(v, nan=0.0, posinf=0.0, neginf=0.0)) for k, v in feats.items()}


def build_feature_matrix(signals, fs: int = FS) -> pd.DataFrame:
    return pd.DataFrame([extract_features(s, fs) for s in signals], columns=FEATURE_NAMES)
