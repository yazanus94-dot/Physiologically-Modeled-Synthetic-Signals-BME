"""Loader for the PhysioNet/CinC Challenge 2017 training set (https://physionet.org/content/challenge-2017/1.0.0/).

Layout after extraction:  training2017/A00001.mat  A00001.hea  ...  REFERENCE.csv  (record,label)
Labels: N = normal, A = AF, O = other rhythm, ~ = too noisy to classify.
"""
import csv
import re
from pathlib import Path

import numpy as np
from scipy.io import loadmat

from ecgaf import FS


def _gain(hea_path: Path) -> float:
    """ADC gain (units per mV) from the .hea header; the 2017 data uses 1000."""
    for line in hea_path.read_text().splitlines()[1:2]:
        m = re.search(r"([\d.]+)/mV", line)
        if m:
            return float(m.group(1))
    return 1000.0


def load_record(prefix: Path):
    """Load <prefix>.mat -> (signal in mV, sampling rate)."""
    prefix = Path(prefix)
    val = loadmat(str(prefix.with_suffix(".mat")))["val"].astype(float).ravel()
    return val / _gain(prefix.with_suffix(".hea")), FS


def load_dataset(data_dir, max_records: int | None = None, include_noisy: bool = False):
    data_dir = Path(data_dir)
    ref = next((data_dir / n for n in ("REFERENCE-v3.csv", "REFERENCE.csv") if (data_dir / n).exists()), None)
    if ref is None:
        raise FileNotFoundError(f"No REFERENCE csv in {data_dir}. Run scripts/download_physionet2017.py first.")
    signals, labels = [], []
    with open(ref) as fh:
        for name, label in csv.reader(fh):
            if label == "~" and not include_noisy:
                continue
            sig, _ = load_record(data_dir / name)
            signals.append(sig)
            labels.append(label)
            if max_records and len(signals) >= max_records:
                break
    return signals, labels
