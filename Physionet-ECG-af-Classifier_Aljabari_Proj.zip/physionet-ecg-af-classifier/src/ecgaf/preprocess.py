import numpy as np
from scipy.signal import butter, sosfiltfilt

from ecgaf import FS


def bandpass(sig: np.ndarray, low: float = 0.5, high: float = 40.0, fs: int = FS, order: int = 4) -> np.ndarray:
    """Zero-phase Butterworth band-pass: removes baseline wander (<0.5 Hz) and high-frequency noise (>40 Hz)."""
    sos = butter(order, [low, high], btype="bandpass", fs=fs, output="sos")
    return sosfiltfilt(sos, sig)


def normalise(sig: np.ndarray) -> np.ndarray:
    """Robust amplitude normalisation (median / IQR) so gain differences between devices do not matter."""
    q1, med, q3 = np.percentile(sig, [25, 50, 75])
    scale = (q3 - q1) or (np.std(sig) or 1.0)
    return (sig - med) / scale
