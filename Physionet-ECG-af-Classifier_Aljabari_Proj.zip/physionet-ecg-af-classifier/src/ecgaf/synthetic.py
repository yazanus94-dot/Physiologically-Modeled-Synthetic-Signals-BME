"""Synthetic single-lead ECG generator (for offline demos and unit tests).

NOT a substitute for real data. It reproduces the *textbook* differences between the classes:
  N  regular RR intervals (small respiratory variability), P wave present
  A  irregularly irregular RR intervals, no P wave, low-amplitude fibrillatory (f) waves
  O  other rhythms: ectopic (premature, wide) beats and a few irregular-but-P-wave-present records
plus baseline wander, mains interference, broadband noise and occasional motion artefacts.
"""
import numpy as np

from ecgaf import FS

# (centre [s relative to R], width [s], amplitude [mV])
_P = (-0.20, 0.025, 0.15)
_QRS_T = [(-0.04, 0.010, -0.12), (0.0, 0.012, 1.0), (0.04, 0.012, -0.20), (0.26, 0.050, 0.30)]
_PVC = [(0.0, 0.035, 1.1), (0.20, 0.070, -0.45)]


def _add_beat(sig: np.ndarray, r_idx: int, waves, scale: float, fs: int) -> None:
    half = int(0.6 * fs)
    lo, hi = max(0, r_idx - half), min(len(sig), r_idx + half)
    t = (np.arange(lo, hi) - r_idx) / fs
    for mu, sd, amp in waves:
        sig[lo:hi] += scale * amp * np.exp(-0.5 * ((t - mu) / sd) ** 2)


def _rr_intervals(label: str, rng, duration: float):
    """Returns (rr_seconds, is_ectopic flags, has_p_wave)."""
    mean_rr = 60.0 / rng.uniform(55, 100)
    n = int(duration / (0.3 * mean_rr)) + 10
    ectopic = np.zeros(n, dtype=bool)
    has_p = True
    if label == "N":
        sigma = rng.choice([0.015, 0.025, 0.04, 0.055], p=[0.4, 0.3, 0.2, 0.1])
        phase = rng.uniform(0, 2 * np.pi)
        k = np.arange(n)
        rr = mean_rr * (1 + 0.04 * np.sin(2 * np.pi * k / rng.uniform(4, 6) + phase) + rng.normal(0, sigma, n))
    elif label == "A":
        sigma = rng.uniform(0.10, 0.24)
        rr = mean_rr * rng.lognormal(0, sigma, n)
        has_p = False
    else:  # "O"
        kind = rng.choice(["ectopic", "irregular_sinus", "pauses"], p=[0.6, 0.25, 0.15])
        if kind == "ectopic":
            rr = mean_rr * (1 + rng.normal(0, 0.03, n))
            p_ect = rng.uniform(0.06, 0.18)
            i = 0
            while i < n - 1:
                if rng.random() < p_ect:
                    ectopic[i] = True
                    rr[i] *= 0.62          # premature beat
                    rr[i + 1] *= 1.35      # compensatory pause
                    i += 2
                else:
                    i += 1
        elif kind == "irregular_sinus":  # overlaps with AF on RR statistics, but P waves remain
            rr = mean_rr * rng.lognormal(0, rng.uniform(0.07, 0.12), n)
        else:
            rr = mean_rr * (1 + rng.normal(0, 0.03, n))
            for j in rng.choice(n - 1, size=rng.integers(1, 4), replace=False):
                rr[j] *= rng.uniform(1.6, 2.2)
    return np.clip(rr, 0.28, 2.4), ectopic, has_p


def generate_record(label: str, rng: np.random.Generator, fs: int = FS, duration: float = 30.0) -> np.ndarray:
    """Return one synthetic ECG record (mV) for class label 'N', 'A' or 'O'."""
    n_samples = int(duration * fs)
    sig = np.zeros(n_samples)
    rr, ectopic, has_p = _rr_intervals(label, rng, duration)
    scale = rng.uniform(0.7, 1.4)
    t_r = rng.uniform(0.2, 0.6)
    for k in range(len(rr)):
        r_idx = int(t_r * fs)
        if r_idx >= n_samples + int(0.6 * fs):
            break
        if ectopic[k]:
            _add_beat(sig, r_idx, _PVC, scale, fs)
        else:
            _add_beat(sig, r_idx, ([_P] if has_p else []) + _QRS_T, scale, fs)
        t_r += rr[k]

    t = np.arange(n_samples) / fs
    if label == "A":  # fibrillatory waves: 4-8 Hz, modulated amplitude
        f1, f2 = rng.uniform(4.5, 6.5), rng.uniform(6.5, 8.5)
        amp = rng.uniform(0.02, 0.07)
        sig += amp * (np.sin(2 * np.pi * f1 * t + rng.uniform(0, 6.3)) + 0.6 * np.sin(2 * np.pi * f2 * t))

    sig += rng.uniform(0.05, 0.3) * np.sin(2 * np.pi * rng.uniform(0.1, 0.4) * t + rng.uniform(0, 6.3))  # baseline wander
    sig += rng.uniform(0.0, 0.03) * np.sin(2 * np.pi * 50 * t)                                             # mains
    sig += rng.normal(0, rng.uniform(0.015, 0.06), n_samples)                                              # sensor noise
    if rng.random() < 0.15:  # motion artefact burst
        s = int(rng.integers(0, n_samples - 2 * fs))
        length = int(rng.uniform(0.5, 2) * fs)
        sig[s:s + length] += rng.normal(0, 0.4, length)
    return sig


def generate_dataset(n_per_class: int = 150, seed: int = 42, fs: int = FS, duration: float = 30.0):
    """Balanced synthetic dataset -> (list of signals, list of labels)."""
    rng = np.random.default_rng(seed)
    signals, labels = [], []
    for label in ("N", "A", "O"):
        for _ in range(n_per_class):
            signals.append(generate_record(label, rng, fs, duration))
            labels.append(label)
    order = rng.permutation(len(signals))
    return [signals[i] for i in order], [labels[i] for i in order]
