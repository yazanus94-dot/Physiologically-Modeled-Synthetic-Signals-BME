"""Download and unzip the PhysioNet/CinC Challenge 2017 training set (~100 MB) into ./data.

Source: https://physionet.org/content/challenge-2017/1.0.0/  (open data, please cite the paper in the README).
Usage:  python scripts/download_physionet2017.py
"""
import urllib.request
import zipfile
from pathlib import Path

URL = "https://physionet.org/files/challenge-2017/1.0.0/training2017.zip"
DEST = Path(__file__).resolve().parent.parent / "data"


def main() -> None:
    DEST.mkdir(exist_ok=True)
    zpath = DEST / "training2017.zip"
    if not zpath.exists():
        print(f"Downloading {URL} ...")
        urllib.request.urlretrieve(URL, zpath)
    print("Extracting ...")
    with zipfile.ZipFile(zpath) as z:
        z.extractall(DEST)
    print("Done ->", DEST / "training2017")


if __name__ == "__main__":
    main()
